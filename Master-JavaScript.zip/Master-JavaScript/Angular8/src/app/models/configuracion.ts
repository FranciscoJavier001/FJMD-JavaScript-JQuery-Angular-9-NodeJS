export let Configuracion = {
  color: "#cccccc",
  fondo: "#101070",
  titulo: "Bienvenido al Master en JavaScript y Angular",
  descripcion: "Aprendiendo Angular con Víctor Robles"
};
