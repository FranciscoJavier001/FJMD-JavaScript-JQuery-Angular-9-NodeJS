export class ContactoUsuario {
  constructor(
    public nombre: string,
    public apellidos: string,
    public email: string,
    public mensaje: string
  ) {}
}
