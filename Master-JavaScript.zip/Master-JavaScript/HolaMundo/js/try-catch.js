'use strict';
window.addEventListener('load', function(){

    try {
        var year = 2019;
        // alert(yea);
        // console.log(decodeURIComponent("https://oversi%stemas.com"));
        var vector = new Array(999999999999999999999999999999999999);
    } catch (error) {
        console.log(error);
        this.alert("A ocurrido un error en el código")
    }

});