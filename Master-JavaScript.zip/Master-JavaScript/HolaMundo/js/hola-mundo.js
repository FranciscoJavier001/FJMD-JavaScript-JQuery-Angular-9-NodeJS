alert("Hola Mundo con JS");
alert("Bienvenido al curso");
// document.write("Hola mundo desde fichero externo");
console.log("Muestra esto en la consola");
console.log(88+4);