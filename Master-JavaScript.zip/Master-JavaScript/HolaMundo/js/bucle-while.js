'use strict';
// BUCLE WHILE
var year = 2019;

// Incremento
while (year <= 2051) {
    // ejecuta esto
    console.log("Estamos en el año :"+year);
    year++;
}
console.log("___________________________________________________");
// Decremento
while (year != 1991) {
    console.log("Es el año: "+year);
    year--;
}