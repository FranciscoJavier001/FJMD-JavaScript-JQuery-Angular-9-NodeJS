'use strict';

var categorias = ['Acción','Terror','Comedia','Romance'];

var peliculas = ['La verdad duele', 'La vida es bella', 'Zoolander', 'Gran torino', 'Tiburon', 'El gran escape'];

//Ordenar un array
console.log(peliculas.sort());
//En reversa
console.log(peliculas.reverse());

