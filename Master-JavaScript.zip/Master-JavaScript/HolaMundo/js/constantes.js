"use strict" //jshint ignore:line

// Constantes
// Su valor no puede cambiar

var web = "https://victorroblesweb.es";
const ip = "192.88.0.12";

web = "httpx://victorroblescursos.es";
// ip = "12.342.32.212";

//una constante su valor no puede ser modificado.
console.log(web, ip);
