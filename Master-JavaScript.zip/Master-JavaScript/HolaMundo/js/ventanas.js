'use strict';

//ALERTA
alert("Esta es mi alerta!!");


//CONFIRMACIÓN
var mi_resultado = confirm('¿Estas seguro de querer continuar?');
console.log(mi_resultado);

// INGRESO DATOS
var mi_respuesta = prompt("¿Que edad tienes?" , 18);
console.log(mi_respuesta);