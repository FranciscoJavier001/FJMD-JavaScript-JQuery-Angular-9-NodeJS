'use strict';
// BUCLE FOR 
// BUCLE es una estructura de control que se repite varias veces

var numero = 100;

for (let i = 1; i <= numero; i++) {
    console.log(i);
    
}    