var saludo : string = "Hola Mundo con TypeScript"
console.log(saludo);
alert("Hola Mundo con TS");