var saludo = "Hola Mundo con TypeScript";
console.log(saludo);
alert("Hola Mundo con TS");
